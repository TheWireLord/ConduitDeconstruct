# Conduit Deconstruct Mod
This mod was designed to help those players, like myself, that find it annoying to have to delete a single power conduit at a time.   With this mod you will be able to not only view your entire power grid (like the blue lines that show up only when using the "Place Conduit" tool) but also designate mass amounts of conduits to be deconstructed.   It is a very simple concept that I believe will be very useful to players out there like me. 

[12.30.2017] - Added support for Industrialisation Mod.

[2.27.2017] - This mod is now compatible with Haplo_X1's PowerSwitch mod.
