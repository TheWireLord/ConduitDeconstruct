﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;


namespace RimWorldMod
{
    public class Designator_DeconstructPowerConduit : Designator_Deconstruct
    {
        public override void DesignateThing(Thing t)
        {
            if (t.def.CanHaveFaction && t.Faction != Faction.OfPlayer)
            {
                t.SetFaction(Faction.OfPlayer, null);
            }
            if (t.def.IsFrame || t.def.IsBlueprint)
            {
                t.Destroy(DestroyMode.Deconstruct);
            }
            else
            {
                base.Map.designationManager.AddDesignation(new Designation(t, DesignationDefOf.Deconstruct));
            }
        }

        public override AcceptanceReport CanDesignateThing(Thing t)
        {
            return (base.CanDesignateThing(t).Accepted && t.def == ThingDefOf.PowerConduit) || (t is Blueprint_Build && (t.def.entityDefToBuild as ThingDef) == ThingDefOf.PowerConduit || t.def.defName == "PowerConduitInvisible");
        }

        public override void SelectedUpdate()
        {
            base.SelectedUpdate();
            OverlayDrawHandler.DrawPowerGridOverlayThisFrame();
        }

        public Designator_DeconstructPowerConduit()
        {
            defaultLabel = "Deconstruct Conduits";
            this.icon = ContentFinder<UnityEngine.Texture2D>.Get("ToolbarIcon/ConduitDeconstructIcon", true);
            hotKey = null;
        }
    }
}
