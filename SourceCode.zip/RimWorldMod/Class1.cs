﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;


namespace RimWorldMod
{
    public class Designator_DeconstructPowerConduit : Designator_Deconstruct
    {
        public override AcceptanceReport CanDesignateThing(Thing t)
        {
            return base.CanDesignateThing(t).Accepted && t.def == ThingDefOf.PowerConduit;
        }

        public override void SelectedUpdate()
        {
            base.SelectedUpdate();
            OverlayDrawHandler.DrawPowerGridOverlayThisFrame();
        }

        public Designator_DeconstructPowerConduit()
        {
            defaultLabel = "Deconstruct Conduits";
            this.icon = ContentFinder<UnityEngine.Texture2D>.Get("ToolbarIcon/ConduitDeconstructIcon", true);
            hotKey = null;
        }
    }
}
